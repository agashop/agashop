<?php
$host1 = "{host}";
$user1 = "{user}";
$pass1 = "{pass}";
$dbname1 = "{dbname}";

?>