<?php
$host1 = "localhost";
$user1 = "root";
$pass1 = "a";
$dbname1 = "nx";

?>